Your Project Name
=================
A brief summary of your project

### Setup / Installation
Some instructions on how to set up and/or install this project

### Staging/Production
This site is staged at http://example.com [u: admin p: example]    
This site is live at http://example.com
